/* =====================================================================
 * LEVEL 3 — SULIT  |  TUGAS 4  |  BERKAS: main.js
 * ---------------------------------------------------------------------
 * SATU-SATUNYA berkas yang boleh memakai DOM dan Event Listener.
 * KERJAKAN SETELAH npm run uji MENUNJUKKAN 32/32.
 * Periksa hasilnya di browser (Live Server) dengan "Daftar Periksa
 * Tampilan" di modul. Buka Console (F12) untuk melihat error.
 *
 * ELEMEN DI index.html YANG HARUS DIPAKAI (berdasarkan id):
 *   #katalog-ruangan   wadah kartu ruangan
 *   #form-pinjam       form peminjaman
 *   #pilihan-ruangan   <select> pilihan ruangan
 *   #nama-peminjam     <input> nama
 *   #jumlah-orang      <input> jumlah orang
 *   #durasi-jam        <input> durasi
 *   #pesan             <p> tempat pesan sukses/gagal
 *   #isi-tabel         <tbody> tabel daftar peminjaman
 *   #total-dipinjam    <strong> total ruangan dipinjam
 *
 * CLASS CSS YANG SUDAH TERSEDIA di style.css:
 *   kartu-ruangan, status, status-tersedia, status-dipinjam,
 *   tombol-batal, pesan, pesan-sukses, pesan-gagal, kosong
 *
 * SPESIFIKASI PERILAKU
 * ---------------------------------------------------------------------
 * TODO 4.1 : Import semua yang dibutuhkan dari data.js, helper.js,
 *            dan peminjaman.js.
 * TODO 4.2 : Katalog menampilkan SEMUA ruangan sebagai kartu: nama,
 *            kapasitas, fasilitas, dan status "Tersedia"/"Dipinjam".
 * TODO 4.3 : Dropdown berisi semua ruangan. Ruangan yang sedang dipinjam
 *            tidak bisa dipilih (disabled).
 * TODO 4.4 : Saat form dikirim: halaman TIDAK reload, data dikirim ke
 *            pinjamRuangan(), pesan sukses/gagal tampil, dan jika sukses
 *            form dikosongkan serta seluruh tampilan diperbarui.
 * TODO 4.5 : Tabel menampilkan No, Ruangan, Peminjam, Jumlah Orang,
 *            Durasi (pakai formatDurasi), dan tombol Batalkan.
 *            Jika kosong: tampilkan "Belum ada ruangan yang dipinjam."
 * TODO 4.6 : Tombol Batalkan membatalkan pinjaman ruangan di barisnya,
 *            lalu memperbarui tampilan. Gunakan SATU listener di #isi-tabel
 *            (event delegation) dan atribut data-id pada tombol.
 * TODO 4.7 : Total ruangan dipinjam selalu sesuai jumlah di tabel.
 *
 * ATURAN KEAMANAN & KERAPIAN
 *   - Teks dari ketikan pengguna (nama peminjam) ditampilkan dengan
 *     textContent, BUKAN innerHTML.
 *   - Buat satu fungsi perbaruiTampilan() yang memanggil semua fungsi
 *     tampilan, dan panggil fungsi itu setiap data berubah.
 *   - Nilai <input> selalu string: ubah ke angka dengan Number().
 *
 * SARAN STRUKTUR (boleh diikuti):
 *   LANGKAH 1 import -> LANGKAH 2 ambil elemen -> LANGKAH 3 fungsi tampilan
 *   -> LANGKAH 4 event listener -> LANGKAH 5 panggil perbaruiTampilan()
 * ===================================================================== */

// LANGKAH 1: IMPORT


// LANGKAH 2: AMBIL ELEMEN HTML


// LANGKAH 3: FUNGSI-FUNGSI TAMPILAN


// LANGKAH 4: EVENT LISTENER


// LANGKAH 5: TAMPILAN AWAL
