/* =====================================================================
 * LEVEL 3 — SULIT  |  TUGAS 3  |  BERKAS: peminjaman.js
 * ---------------------------------------------------------------------
 * Kelola STATE peminjaman memakai struktur data Map.
 * Target bagian "TUGAS 3 — peminjaman.js": Skor bagian 18/18.
 *
 * ATURAN UMUM
 *   - DILARANG memakai document, alert, innerHTML, atau kode DOM lain.
 *   - Fungsi cukup MENGEMBALIKAN hasil. main.js yang menampilkannya.
 *   - Map penyimpan data TIDAK BOLEH di-export (state privat).
 *
 * ---------------------------------------------------------------------
 * TODO 3.1 : Persiapan
 *   - import fungsi cekKapasitas dari './helper.js'
 *   - buat Map bernama daftarPinjaman
 *       kunci = id ruangan, nilai = objek data peminjaman
 *
 * ---------------------------------------------------------------------
 * TODO 3.2 : pinjamRuangan(ruangan, namaPeminjam, jumlahOrang, durasiJam)
 *   Parameter : ruangan (objek dari data.js, bisa undefined),
 *               namaPeminjam (string), jumlahOrang (number), durasiJam (number)
 *   Return    : objek { berhasil: boolean, pesan: string }
 *   Validasi (urutan PENTING, berhenti di validasi pertama yang gagal):
 *     1. ruangan tidak ada (undefined)            -> gagal
 *     2. ruangan sudah ada di Map (sedang dipinjam) -> gagal
 *     3. nama kosong atau hanya berisi spasi      -> gagal
 *     4. jumlah orang tidak muat (pakai cekKapasitas) -> gagal
 *     5. durasi bukan angka valid atau <= 0       -> gagal
 *   Jika semua lolos, simpan ke Map objek berisi:
 *     idRuangan, namaRuangan, namaPeminjam (sudah di-trim), jumlahOrang, durasiJam
 *   lalu kembalikan { berhasil: true, pesan: '...' }.
 *   Setiap pesan berisi kalimat yang jelas untuk pengguna (bebas).
 *
 * ---------------------------------------------------------------------
 * TODO 3.3 : batalkanPinjaman(idRuangan)  -> boolean
 *   Menghapus data. true jika ada yang terhapus, false jika tidak ada.
 *
 * TODO 3.4 : hitungTotalDipinjam()        -> number
 *   Jumlah ruangan yang sedang dipinjam.
 *
 * TODO 3.5 : sedangDipinjam(idRuangan)    -> boolean
 *   true jika ruangan sedang dipinjam.
 *
 * TODO 3.6 : ambilDaftarPinjaman()        -> array
 *   Semua data peminjaman (nilai-nilai Map) dalam bentuk ARRAY.
 *
 * TODO 3.7 : resetPinjaman()              -> (tidak mengembalikan apa-apa)
 *   Menghapus SEMUA data peminjaman. Dipakai oleh penguji.
 *
 * Semua fungsi di atas WAJIB di-export.
 * ===================================================================== */

// Tulis kodemu di bawah ini.
