# Level 3 — Sulit · Sistem Peminjaman Ruangan

Di level ini kamu **menulis semua kode sendiri**. Setiap berkas hanya berisi **spesifikasi**: nama, parameter, nilai kembalian, aturan, dan contoh. Penguji otomatis memeriksa apakah kodemu sesuai spesifikasi.

## Urutan Kerja

| Tugas | Berkas | Yang dikerjakan | Cara cek |
|---|---|---|---|
| 1 | `data.js` | TODO 1.1 | `npm run uji` → Tugas 1 = 5/5 |
| 2 | `helper.js` | TODO 2.1 – 2.2 | `npm run uji` → Tugas 2 = 9/9 |
| 3 | `peminjaman.js` | TODO 3.1 – 3.7 | `npm run uji` → Tugas 3 = 18/18 |
| 4 | `main.js` | TODO 4.1 – 4.7 | Live Server + Daftar Periksa Tampilan |

## Cara Menjalankan

1. Buka folder ini di VS Code.
2. Buka terminal (**Terminal → New Terminal**), lalu ketik `npm run uji`.
3. Untuk Tugas 4: klik kanan `index.html` → **Open with Live Server**. Tekan **F12** untuk membuka Console.

> Baca spesifikasi sampai selesai sebelum mulai menulis.
> Jangan ubah `uji-logika.mjs`, `index.html`, dan `style.css`.
