/* =====================================================================
 * LEVEL 3 — SULIT  |  TUGAS 2  |  BERKAS: helper.js
 * ---------------------------------------------------------------------
 * Tulis dan EXPORT dua FUNGSI MURNI sesuai spesifikasi berikut.
 * Target bagian "TUGAS 2 — helper.js": Skor bagian 9/9.
 *
 * Fungsi murni = input sama -> hasil selalu sama, tidak mengubah apa pun
 * di luar dirinya, dan tidak menyentuh DOM.
 *
 * ---------------------------------------------------------------------
 * TODO 2.1 : formatDurasi(jam)
 * ---------------------------------------------------------------------
 *   Parameter : jam (number) — lama peminjaman dalam jam, boleh pecahan
 *   Return    : string
 *   Aturan    :
 *     - jam bukan angka yang valid (NaN/Infinity) atau jam <= 0
 *         -> 'Durasi tidak valid'
 *     - ubah ke menit (dibulatkan), lalu tampilkan:
 *         hanya menit       -> '30 menit'
 *         hanya jam         -> '2 jam'
 *         jam dan menit     -> '1 jam 30 menit'
 *   Contoh    :
 *     | input | output               |
 *     |-------|----------------------|
 *     | 2     | '2 jam'              |
 *     | 1.5   | '1 jam 30 menit'     |
 *     | 0.5   | '30 menit'           |
 *     | 0     | 'Durasi tidak valid' |
 *
 * ---------------------------------------------------------------------
 * TODO 2.2 : cekKapasitas(jumlahOrang, kapasitasRuang)
 * ---------------------------------------------------------------------
 *   Parameter : jumlahOrang (number), kapasitasRuang (number)
 *   Return    : boolean
 *   Aturan    : true hanya jika 0 < jumlahOrang <= kapasitasRuang
 *   Contoh    :
 *     | input    | output |
 *     |----------|--------|
 *     | (30, 36) | true   |
 *     | (36, 36) | true   |
 *     | (40, 36) | false  |
 *     | (0, 36)  | false  |
 *
 * TANTANGAN TAMBAHAN: tulis tiap fungsi sesingkat dan sejelas mungkin,
 * lalu beri komentar singkat pada bagian yang menurutmu sulit dipahami.
 * ===================================================================== */

// Tulis kodemu di bawah ini.
