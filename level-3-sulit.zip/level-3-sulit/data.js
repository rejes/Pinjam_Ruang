/* =====================================================================
 * LEVEL 3 — SULIT  |  TUGAS 1  |  BERKAS: data.js
 * ---------------------------------------------------------------------
 * Di level ini kamu menulis SEMUA kode sendiri berdasarkan SPESIFIKASI.
 * Jalankan  npm run uji  setelah setiap perubahan.
 * Target bagian "TUGAS 1 — data.js": Skor bagian 5/5.
 *
 * SPESIFIKASI
 * ---------------------------------------------------------------------
 * TODO 1.1 : Buat dan EXPORT sebuah konstanta bernama daftarRuangan.
 *
 *   Tipe      : Array of Objects
 *   Isi       : MINIMAL 4 ruangan, mencakup Lab Komputer, Aula,
 *               Ruang Rapat, dan Ruang Kelas.
 *   Properti setiap objek:
 *     | properti    | tipe            | contoh                       |
 *     |-------------|-----------------|------------------------------|
 *     | id          | string (unik)   | 'R01'                        |
 *     | namaRuangan | string          | 'Lab Komputer RPL'           |
 *     | kapasitas   | number (> 0)    | 36                           |
 *     | fasilitas   | array of string | ['36 Unit PC', 'AC']         |
 *
 * ATURAN
 *   - Berkas ini hanya berisi data. Tanpa fungsi dan tanpa kode DOM.
 *   - Nama variabel dan properti HARUS sama persis (huruf besar/kecil
 *     berpengaruh), karena dipakai oleh berkas lain dan oleh penguji.
 * ===================================================================== */

// Tulis kodemu di bawah ini.
